# Portfolio Website

## Overview

This is a personal portfolio website for Nivethidha S, built as a full-stack web application showcasing her professional work, skills, and projects. The application features a modern, dark-themed design with smooth animations and responsive layout.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Animations**: Framer Motion for smooth transitions and interactions
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Development**: Hot reload with Vite integration

### Design System
- **Component Library**: Shadcn/ui with "new-york" style variant
- **Theme**: Dark mode with custom CSS variables
- **Color Scheme**: Blue and cyan accent colors with neutral base
- **Typography**: Inter font family
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints

## Key Components

### Frontend Components
- **Navigation**: Sticky header with smooth scroll navigation
- **Hero Section**: Personal introduction with gradient effects
- **About Section**: Professional background and journey
- **Skills Section**: Technical skills categorized by type (Programming, Web Tech, Databases, Tools)
- **Projects Section**: Portfolio projects with technology badges
- **Resume Section**: Education, certifications, and publications
- **Contact Section**: Contact form and information
- **Footer**: Simple footer with copyright

### Backend Components
- **Storage Interface**: Abstracted storage layer with in-memory implementation
- **User Management**: Basic user CRUD operations (currently unused in portfolio)
- **Route Registration**: Centralized route management
- **Error Handling**: Global error middleware
- **Development Tools**: Vite integration for hot reload

### UI Component System
- **Comprehensive Component Library**: 40+ reusable components
- **Form Components**: Input, textarea, select, checkbox, radio groups
- **Layout Components**: Cards, separators, sheets, dialogs
- **Feedback Components**: Toasts, tooltips, progress indicators
- **Navigation Components**: Menus, breadcrumbs, pagination

## Data Flow

### Current Implementation
- **Static Portfolio**: All portfolio data is hardcoded in components
- **Contact Form**: Form submission handled client-side with toast notifications
- **No Database Integration**: Database schema exists but is not currently used

### Database Schema
- **Users Table**: Basic user management (id, username, password)
- **Validation**: Zod schemas for type-safe data validation
- **Migrations**: Drizzle migrations in `./migrations` directory

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React, React DOM, React Query
- **UI Framework**: Radix UI primitives, Tailwind CSS
- **Database**: Drizzle ORM, Neon Database serverless driver
- **Animations**: Framer Motion
- **Form Handling**: React Hook Form with Hookform Resolvers
- **Validation**: Zod for schema validation
- **Date Handling**: date-fns for date manipulation

### Development Tools
- **Build Tools**: Vite, esbuild for production builds
- **TypeScript**: Full TypeScript support with strict configuration
- **Linting/Formatting**: Configuration for code quality
- **Replit Integration**: Replit-specific plugins and error handling

## Deployment Strategy

### Build Process
- **Development**: `npm run dev` - Runs with tsx and hot reload
- **Production Build**: `npm run build` - Vite build + esbuild for server
- **Database**: `npm run db:push` - Drizzle schema push to database

### Environment Configuration
- **Database URL**: Required environment variable for PostgreSQL connection
- **Build Outputs**: 
  - Client: `dist/public` directory
  - Server: `dist/index.js` bundle

### Hosting Considerations
- **Static Assets**: Client built as static files served by Express
- **Server Rendering**: No SSR, pure SPA with Express API backend
- **Database**: Serverless PostgreSQL via Neon
- **Environment**: Designed for Replit deployment with specific integrations

### Development vs Production
- **Development**: Vite dev server with HMR, Replit-specific tooling
- **Production**: Express serves static files, compiled server bundle
- **Error Handling**: Different error overlays for development vs production