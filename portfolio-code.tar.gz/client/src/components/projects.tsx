import { motion } from "framer-motion";
import { Search, ShoppingCart, Brain, Github, ExternalLink } from "lucide-react";

export default function Projects() {
  const projects = [
    {
      title: "Plagiarism Checker Web Application",
      description: "Built an application to check text for plagiarism, providing similarity scores and highlighting matches. Offers real-time feedback with an intuitive interface.",
      technologies: ["HTML", "CSS", "JavaScript"],
      icon: Search,
      gradient: "from-[var(--primary-blue)] to-[var(--secondary-cyan)]",
      techColors: {
        "HTML": "bg-orange-500/20 text-orange-400",
        "CSS": "bg-blue-500/20 text-blue-400", 
        "JavaScript": "bg-yellow-500/20 text-yellow-400"
      }
    },
    {
      title: "Cake Order Express",
      description: "Developed an online platform for users to order and customize cakes, managed by home-based entrepreneurs. Features a responsive design and seamless ordering experience.",
      technologies: ["HTML", "CSS", "Java", "XAMPP"],
      icon: ShoppingCart,
      gradient: "from-pink-500 to-orange-500",
      techColors: {
        "HTML": "bg-orange-500/20 text-orange-400",
        "CSS": "bg-blue-500/20 text-blue-400",
        "Java": "bg-red-500/20 text-red-400",
        "XAMPP": "bg-purple-500/20 text-purple-400"
      }
    },
    {
      title: "Intelligent Study Planner",
      description: "Developed a study planner app that helps students set goals, track progress, and manage time effectively. Provides personalized recommendations for efficient scheduling.",
      technologies: ["HTML", "CSS", "React", "Node.js", "MongoDB"],
      icon: Brain,
      gradient: "from-emerald-500 to-blue-500",
      techColors: {
        "HTML": "bg-orange-500/20 text-orange-400",
        "CSS": "bg-blue-500/20 text-blue-400",
        "React": "bg-cyan-500/20 text-cyan-400",
        "Node.js": "bg-green-500/20 text-green-400",
        "MongoDB": "bg-emerald-500/20 text-emerald-400"
      }
    }
  ];

  return (
    <section id="projects" className="py-20 bg-[var(--dark-card)]/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">Featured Projects</h2>
          <div className="w-20 h-1 bg-[var(--primary-blue)] mx-auto"></div>
        </motion.div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-[var(--dark-bg)] rounded-xl overflow-hidden card-hover"
            >
              {/* Project Icon/Image */}
              <div className={`h-48 bg-gradient-to-br ${project.gradient} flex items-center justify-center`}>
                <project.icon className="w-16 h-16 text-white" />
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">{project.title}</h3>
                <p className="text-slate-300 mb-4 leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, techIndex) => (
                    <motion.span
                      key={tech}
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.2 + techIndex * 0.1 }}
                      viewport={{ once: true }}
                      className={`${project.techColors[tech]} px-2 py-1 rounded text-xs`}
                    >
                      {tech}
                    </motion.span>
                  ))}
                </div>
                
                <div className="flex space-x-4">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center text-[var(--primary-blue)] hover:text-[var(--secondary-cyan)] transition-colors"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center text-[var(--primary-blue)] hover:text-[var(--secondary-cyan)] transition-colors"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Demo
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
