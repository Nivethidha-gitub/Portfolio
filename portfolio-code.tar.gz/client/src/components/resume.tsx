import { motion } from "framer-motion";
import { GraduationCap, Award, BookOpen, Users, CheckCircle } from "lucide-react";

export default function Resume() {
  const education = [
    {
      degree: "B.Tech - Information Technology",
      institution: "Sri Shakthi Institute of Engineering And Technology",
      period: "2022 – 2026",
      location: "Coimbatore, India",
      grade: "CGPA: 8.52*",
      color: "border-[var(--primary-blue)]",
      textColor: "text-[var(--primary-blue)]"
    },
    {
      degree: "HSLC - State Board",
      institution: "Grd-Cpf Matriculation.Hr.Sec.School",
      period: "2021 – 2022",
      location: "Coimbatore, India",
      grade: "Percentage: 84.16%",
      color: "border-[var(--secondary-cyan)]",
      textColor: "text-[var(--secondary-cyan)]"
    },
    {
      degree: "SSLC - State Board",
      institution: "Grd-Cpf Matriculation.Hr.Sec.School",
      period: "2019 – 2020",
      location: "Coimbatore, India",
      grade: "Percentage: 83.2%",
      color: "border-emerald-400",
      textColor: "text-emerald-400"
    }
  ];

  const certifications = [
    { name: "Cloud Computing (AWS)", provider: "Rampex Technologies" },
    { name: "Flexbox, SQL, MernStack", provider: "Unstop Academy" },
    { name: "Full Stack in Java", provider: "Indra Institute" },
    { name: "Flipkart 5.0 Participation", provider: "Unstop" },
    { name: "Hindi Language Proficiency", provider: "8 Levels Completed" }
  ];

  const publications = [
    {
      id: "patent-1",
      type: "Patent",
      title: "Intelligent Study Planner",
      details: "DOI Number: 140105"
    },
    {
      id: "paper-1",
      type: "Paper Publication",
      title: "Intelligent Study Planner",
      details: "International Journal Of Progressive Research in Engineering Management and Science"
    }
  ];

  const workshops = [
    {
      title: "AWD Management Services",
      location: "Coimbatore | One day",
      description: "Spearheaded the implementation of new technologies to modernize software processes and increase efficiency."
    },
    {
      title: "Dr.N.G.P Institute of Technology",
      location: "Coimbatore | March 04, 2024",
      description: "Workshop on \"Deep Learning & Large Language Model in HR Analytics\" during HENOSIS 2K24."
    }
  ];

  return (
    <section id="resume" className="py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">Resume</h2>
          <div className="w-20 h-1 bg-[var(--primary-blue)] mx-auto"></div>
        </motion.div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Education */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-[var(--dark-card)] p-8 rounded-xl"
          >
            <h3 className="text-2xl font-semibold mb-6 flex items-center">
              <GraduationCap className="w-6 h-6 text-[var(--primary-blue)] mr-3" />
              Education
            </h3>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <motion.div
                  key={edu.degree}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className={`border-l-4 ${edu.color} pl-6`}
                >
                  <h4 className="font-semibold text-lg">{edu.degree}</h4>
                  <p className={`${edu.textColor} font-medium`}>{edu.institution}</p>
                  <p className="text-slate-400">{edu.period} | {edu.location}</p>
                  <p className="text-emerald-400 font-medium">{edu.grade}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Certifications & Publications */}
          <div className="space-y-8">
            {/* Certifications */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-[var(--dark-card)] p-8 rounded-xl"
            >
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <Award className="w-6 h-6 text-[var(--secondary-cyan)] mr-3" />
                Certifications
              </h3>
              <div className="space-y-4">
                {certifications.map((cert, index) => (
                  <motion.div
                    key={cert.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start space-x-3"
                  >
                    <CheckCircle className="w-5 h-5 text-emerald-400 mt-1" />
                    <div>
                      <p className="font-medium">{cert.name}</p>
                      <p className="text-slate-400 text-sm">{cert.provider}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Publications */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-[var(--dark-card)] p-8 rounded-xl"
            >
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <BookOpen className="w-6 h-6 text-amber-400 mr-3" />
                Publications
              </h3>
              <div className="space-y-4">
                {publications.map((pub, index) => (
                  <motion.div
                    key={pub.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.2 }}
                    viewport={{ once: true }}
                    className="border border-amber-400/20 p-4 rounded-lg"
                  >
                    <h4 className="font-semibold text-amber-400 mb-2">{pub.type}</h4>
                    <p className="font-medium">{pub.title}</p>
                    <p className="text-slate-400 text-sm">{pub.details}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Workshops */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-12 bg-[var(--dark-card)] p-8 rounded-xl"
        >
          <h3 className="text-2xl font-semibold mb-6 flex items-center">
            <Users className="w-6 h-6 text-purple-400 mr-3" />
            Workshops & Experience
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            {workshops.map((workshop, index) => (
              <motion.div
                key={workshop.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                viewport={{ once: true }}
                className="border border-purple-400/20 p-6 rounded-lg"
              >
                <h4 className="font-semibold text-purple-400 mb-2">{workshop.title}</h4>
                <p className="text-slate-300 mb-2">{workshop.location}</p>
                <p className="text-slate-400 text-sm">{workshop.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
