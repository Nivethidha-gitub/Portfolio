import { motion } from "framer-motion";
import { CheckCircle } from "lucide-react";

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
      },
    },
  };

  return (
    <section id="about" className="py-20 bg-[var(--dark-card)]/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">About Me</h2>
          <div className="w-20 h-1 bg-[var(--primary-blue)] mx-auto"></div>
        </motion.div>
        
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-12 items-center"
        >
          <motion.div variants={itemVariants}>
            <h3 className="text-2xl font-semibold mb-6 text-slate-100">Professional Journey</h3>
            <p className="text-slate-300 mb-6 leading-relaxed">
              I'm a dedicated Information Technology student at Sri Shakthi Institute of Engineering And Technology 
              with a current CGPA of 8.52. My passion lies in creating innovative web applications and exploring 
              the latest technologies in software development.
            </p>
            <p className="text-slate-300 mb-6 leading-relaxed">
              With expertise in modern web technologies including React.js, Node.js, and MongoDB, I've developed 
              several projects ranging from plagiarism checkers to intelligent study planners. My goal is to 
              contribute to meaningful software solutions that make a positive impact.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mt-8">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="bg-[var(--dark-bg)] p-4 rounded-lg"
              >
                <h4 className="font-semibold text-[var(--primary-blue)] mb-2">Location</h4>
                <p className="text-slate-300">Coimbatore, India</p>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="bg-[var(--dark-bg)] p-4 rounded-lg"
              >
                <h4 className="font-semibold text-[var(--primary-blue)] mb-2">Education</h4>
                <p className="text-slate-300">B.Tech IT (2022-2026)</p>
              </motion.div>
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <div className="bg-[var(--dark-bg)] p-8 rounded-xl">
              <h3 className="text-xl font-semibold mb-6 text-slate-100">Key Strengths</h3>
              <div className="space-y-4">
                {[
                  "Reliable and Responsible",
                  "Highly organized and efficient",
                  "Team Work Management"
                ].map((strength, index) => (
                  <motion.div
                    key={strength}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.2 }}
                    viewport={{ once: true }}
                    className="flex items-center space-x-3"
                  >
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span className="text-slate-300">{strength}</span>
                  </motion.div>
                ))}
              </div>
              
              <h3 className="text-xl font-semibold mb-6 mt-8 text-slate-100">Languages</h3>
              <div className="flex flex-wrap gap-2">
                {["Telugu", "Tamil", "English", "Hindi"].map((language, index) => (
                  <motion.span
                    key={language}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="bg-[var(--primary-blue)]/20 text-[var(--primary-blue)] px-3 py-1 rounded-full text-sm"
                  >
                    {language}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
