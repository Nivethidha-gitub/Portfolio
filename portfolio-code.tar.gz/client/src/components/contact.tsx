import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Linkedin, Github, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement form submission logic
    toast({
      title: "Message Sent!",
      description: "Thank you for your message. I'll get back to you soon.",
    });
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      info: "nivethidha715@gmail.com",
      color: "text-[var(--primary-blue)]",
      bgColor: "bg-[var(--primary-blue)]/20"
    },
    {
      icon: Phone,
      title: "Phone",
      info: "9715561005",
      color: "text-[var(--secondary-cyan)]",
      bgColor: "bg-[var(--secondary-cyan)]/20"
    },
    {
      icon: MapPin,
      title: "Location",
      info: "Teachers colony, Chinniyampalayam, Coimbatore - 641062",
      color: "text-emerald-400",
      bgColor: "bg-emerald-400/20"
    }
  ];

  const socialLinks = [
    { icon: Linkedin, color: "text-blue-400", bgColor: "bg-blue-600/20 hover:bg-blue-600/30" },
    { icon: Github, color: "text-gray-400", bgColor: "bg-gray-600/20 hover:bg-gray-600/30" },
    { icon: Code, color: "text-orange-400", bgColor: "bg-orange-600/20 hover:bg-orange-600/30" }
  ];

  return (
    <section id="contact" className="py-20 bg-[var(--dark-card)]/50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">Get In Touch</h2>
          <div className="w-20 h-1 bg-[var(--primary-blue)] mx-auto mb-6"></div>
          <p className="text-xl text-slate-300">Let's collaborate on your next project</p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {contactInfo.map((contact, index) => (
              <motion.div
                key={contact.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                viewport={{ once: true }}
                className="flex items-center space-x-4"
              >
                <div className={`w-12 h-12 ${contact.bgColor} rounded-lg flex items-center justify-center`}>
                  <contact.icon className={`w-6 h-6 ${contact.color}`} />
                </div>
                <div>
                  <h3 className="font-semibold">{contact.title}</h3>
                  <p className="text-slate-300">{contact.info}</p>
                </div>
              </motion.div>
            ))}
            
            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              viewport={{ once: true }}
              className="pt-8"
            >
              <h3 className="font-semibold mb-4">Connect with me</h3>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className={`w-12 h-12 ${social.bgColor} rounded-lg flex items-center justify-center transition-colors`}
                  >
                    <social.icon className={`w-6 h-6 ${social.color}`} />
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </motion.div>
          
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-[var(--dark-bg)] p-8 rounded-xl"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Name</label>
                <Input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your Name"
                  required
                  className="bg-[var(--dark-card)] border-[var(--dark-lighter)] text-slate-100 focus:border-[var(--primary-blue)]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your.email@example.com"
                  required
                  className="bg-[var(--dark-card)] border-[var(--dark-lighter)] text-slate-100 focus:border-[var(--primary-blue)]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Subject</label>
                <Input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="Project Discussion"
                  required
                  className="bg-[var(--dark-card)] border-[var(--dark-lighter)] text-slate-100 focus:border-[var(--primary-blue)]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Message</label>
                <Textarea
                  rows={5}
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Tell me about your project..."
                  required
                  className="bg-[var(--dark-card)] border-[var(--dark-lighter)] text-slate-100 focus:border-[var(--primary-blue)] resize-none"
                />
              </div>
              
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button
                  type="submit"
                  className="w-full bg-[var(--primary-blue)] hover:bg-blue-600 text-white py-3 font-medium"
                >
                  Send Message
                </Button>
              </motion.div>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
