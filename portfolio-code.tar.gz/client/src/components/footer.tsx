import { motion } from "framer-motion";

export default function Footer() {
  return (
    <footer className="bg-[var(--dark-bg)] border-t border-[var(--dark-lighter)] py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-slate-400">&copy; 2024 Nivethidha S. All rights reserved.</p>
          <p className="text-slate-500 text-sm mt-2">Built with React, Tailwind CSS, and lots of ☕</p>
        </motion.div>
      </div>
    </footer>
  );
}
