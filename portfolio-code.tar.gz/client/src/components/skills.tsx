import { motion } from "framer-motion";
import { Code, Globe, Database, Wrench } from "lucide-react";

export default function Skills() {
  const skillCategories = [
    {
      title: "Programming",
      icon: Code,
      color: "text-[var(--primary-blue)]",
      bgColor: "bg-[var(--primary-blue)]/20",
      skills: [
        { name: "Java", level: 85 },
        { name: "JavaScript", level: 80 }
      ]
    },
    {
      title: "Web Tech",
      icon: Globe,
      color: "text-[var(--secondary-cyan)]",
      bgColor: "bg-[var(--secondary-cyan)]/20",
      skills: ["HTML", "CSS", "React.js", "Bootstrap", "Node.js"]
    },
    {
      title: "Databases",
      icon: Database,
      color: "text-emerald-400",
      bgColor: "bg-emerald-400/20",
      skills: ["MySQL", "MongoDB", "XAMPP"]
    },
    {
      title: "Tools",
      icon: Wrench,
      color: "text-amber-400",
      bgColor: "bg-amber-400/20",
      skills: ["VS Code", "Eclipse", "NetBeans", "AWS"]
    }
  ];

  const areasOfInterest = [
    "Full Stack Development",
    "Web Development", 
    "Designing",
    "Networking"
  ];

  return (
    <section id="skills" className="py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">Skills & Technologies</h2>
          <div className="w-20 h-1 bg-[var(--primary-blue)] mx-auto"></div>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-[var(--dark-card)] p-6 rounded-xl card-hover"
            >
              <div className="flex items-center mb-4">
                <category.icon className={`w-8 h-8 ${category.color} mr-3`} />
                <h3 className="text-xl font-semibold">{category.title}</h3>
              </div>
              
              {category.title === "Programming" ? (
                <div className="space-y-3">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skill.name} className="flex justify-between items-center">
                      <span className="text-slate-300">{skill.name}</span>
                      <div className="w-16 h-2 bg-[var(--dark-bg)] rounded-full">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${(skill.level / 100) * 100}%` }}
                          transition={{ delay: index * 0.2 + skillIndex * 0.2, duration: 1 }}
                          viewport={{ once: true }}
                          className={`h-2 bg-[var(--primary-blue)] rounded-full`}
                          style={{ width: `${(skill.level / 100) * 64}px` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {category.skills.map((skill, skillIndex) => (
                    <motion.span
                      key={skill}
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.2 + skillIndex * 0.1 }}
                      viewport={{ once: true }}
                      className={`inline-block ${category.bgColor} ${category.color} px-2 py-1 rounded text-sm mr-2 mb-2`}
                    >
                      {skill}
                    </motion.span>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Area of Interest */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-12"
        >
          <h3 className="text-2xl font-semibold text-center mb-8">Areas of Interest</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {areasOfInterest.map((area, index) => (
              <motion.span
                key={area}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.2 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.1 }}
                className="bg-gradient-to-r from-[var(--primary-blue)] to-[var(--secondary-cyan)] text-white px-6 py-3 rounded-full font-medium"
              >
                {area}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
